-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2022 at 05:09 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rockss`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_event` datetime DEFAULT NULL,
  `end_event` datetime NOT NULL,
  `identification` varchar(255) NOT NULL,
  `guard_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `title`, `start_event`, `end_event`, `identification`, `guard_id`) VALUES
(106, 'attended', '2022-09-16 00:00:00', '2022-09-16 00:00:00', 'DIFDFSDF', 137),
(110, 'attended', '2022-09-19 00:00:00', '2022-09-19 00:00:00', 'DIFDFSDF', 137),
(111, 'attended', '2022-09-20 00:00:00', '2022-09-20 00:00:00', 'DIFDFSDF', 137),
(112, 'attended', '2022-10-04 00:00:00', '2022-10-04 00:00:00', 'DIFDFSDF', 137),
(113, 'attended', '2022-10-10 00:00:00', '2022-10-10 00:00:00', 'DIFDFSDF', 137),
(114, 'attended', '2022-10-22 00:00:00', '2022-10-22 00:00:00', 'DIFDFSDF', 137),
(115, 'attended', '2022-10-22 00:00:00', '2022-10-22 00:00:00', 'ISNGISD232', 141),
(116, 'attended', '2022-10-22 00:00:00', '2022-10-22 00:00:00', 'TYUDFAL', 138);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `address`, `contact`, `image`, `date`) VALUES
(136, 'Bigman', 'Zomba', 'Css@74.com', 'profile.png', '2022-09-16 00:00:00'),
(137, 'Neo james', 'Dxomba ', 'Neo@maker.com', 'profile.png', '2022-10-10 00:00:00'),
(138, 'banda', 'area 34', '083882938', 'profile.png', '2022-10-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `guard`
--

CREATE TABLE `guard` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `identification` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `certificate` varchar(255) DEFAULT NULL,
  `information` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `schedule` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guard`
--

INSERT INTO `guard` (`id`, `firstname`, `lastname`, `identification`, `contact`, `education`, `height`, `certificate`, `information`, `image`, `date`, `schedule`) VALUES
(137, 'matias', 'jana', 'DIFDFSDF', 'bckyrd.io@gmail.com', 'tetiary', '32', 'diploma', 'nigeria', 'images (1).jpg', '2022-09-16 15:07:32', 'interview'),
(138, 'mercy', 'bro', 'TYUDFAL', 'bckyrd.io@gmail.com', 'tetiary', '42', 'degree', 'ghana', 'download (1).jpg', '2022-09-16 15:10:22', ''),
(139, 'bogara', 'adni', 'ASDFD12', 'bogara5791@dnitem.com', 'medicine', '32', 'nursing', 'india', 'images.jpg', '2022-09-19 10:38:04', 'training'),
(140, 'mellz', 'kumpanje', 'MELLZKUMP001', 'parabi9828@civikli.com', 'hustle', '22', 'arts', 'bangwe', 'Guntolah-ft-Mellz-x-Thinka-spark-bello-child-mp3-image.jpg', '2022-10-04 08:15:05', 'training'),
(141, 'petro', 'simon', 'ISNGISD232', 'betifi1343@abudat.com', 'tertialy', '2.5', 'security advanced', 'mulanje', 'cameroon.jpg', '2022-10-22 11:16:07', 'training');

-- --------------------------------------------------------

--
-- Table structure for table `guard_on_inventory`
--

CREATE TABLE `guard_on_inventory` (
  `id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `guard_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `no` varchar(200) DEFAULT NULL,
  `qty_return` int(11) DEFAULT NULL,
  `no_return` varchar(200) DEFAULT NULL,
  `submited` datetime DEFAULT NULL,
  `returned` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guard_on_inventory`
--

INSERT INTO `guard_on_inventory` (`id`, `inventory_id`, `guard_id`, `qty`, `no`, `qty_return`, `no_return`, `submited`, `returned`) VALUES
(34, 1, 137, 56, '#dgsg3', 56, '#dgsg3', '2022-09-16 16:46:02', '2022-09-16 16:49:29'),
(35, 1, 137, 9, '#yu,ui', NULL, NULL, '2022-09-17 05:36:44', NULL),
(36, 2, 139, 3, 'item number 7', NULL, NULL, '2022-09-19 10:42:37', NULL),
(37, 3, 141, 2, '#1332,#443', NULL, NULL, '2022-10-22 11:25:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `ppe` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `ppe`) VALUES
(1, 'boots'),
(2, 'trousers'),
(3, 'shirt'),
(4, 'belt'),
(5, 'sweater'),
(6, 'cap'),
(7, 'batton stick'),
(8, 'lanyard and whistle');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE `posting` (
  `id` int(11) NOT NULL,
  `guard_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`id`, `guard_id`, `customer_id`, `date`) VALUES
(116, 137, 136, '2022-09-16 15:25:47'),
(117, 139, 136, '2022-09-19 10:44:13'),
(120, 141, 138, '2022-10-22 11:34:59'),
(121, 138, 138, '2022-10-22 11:35:29');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` int(11) NOT NULL,
  `guard_id` int(11) NOT NULL,
  `month` datetime NOT NULL,
  `total` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`id`, `guard_id`, `month`, `total`) VALUES
(8, 137, '2022-09-19 00:00:00', 44000),
(9, 141, '2022-10-22 00:00:00', 44000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guard_id` (`guard_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guard`
--
ALTER TABLE `guard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guard_on_inventory`
--
ALTER TABLE `guard_on_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guard_on_inventory_ibfk_1` (`guard_id`),
  ADD KEY `guard_on_inventory_ibfk_2` (`inventory_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posting`
--
ALTER TABLE `posting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posting_ibfk_1` (`customer_id`),
  ADD KEY `posting_ibfk_2` (`guard_id`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guard_id` (`guard_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `guard`
--
ALTER TABLE `guard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `guard_on_inventory`
--
ALTER TABLE `guard_on_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `posting`
--
ALTER TABLE `posting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`guard_id`) REFERENCES `guard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `guard_on_inventory`
--
ALTER TABLE `guard_on_inventory`
  ADD CONSTRAINT `guard_on_inventory_ibfk_1` FOREIGN KEY (`guard_id`) REFERENCES `guard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guard_on_inventory_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posting`
--
ALTER TABLE `posting`
  ADD CONSTRAINT `posting_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posting_ibfk_2` FOREIGN KEY (`guard_id`) REFERENCES `guard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salaries`
--
ALTER TABLE `salaries`
  ADD CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`guard_id`) REFERENCES `guard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
